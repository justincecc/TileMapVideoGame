# Project 2 
 
## Cyclops Escape
 
* Justin Cecc (jac2524) 
* Jensen Roe (jr2999) 
 
## Instructions 
 
click anywhere on the start screen to begin
the controls are on the main screen
move through the levels from bottom left to the top right to get to the next room
attack the monsters by left clicking on jumping on them

 
## Known Bugs or Issues 
 
jumping on a monster will cause all monsters to die for that level
end screen sometimes does not show up (unknown cause)
 
## Credits 
 
Justin: Created hero sprite, monster sprite, hit detection, animation sequence, event handling
Jensen: created title and end screen, added 3 rooms with additional monsters and layouts, fixed some bugs with the monsters not spawning.